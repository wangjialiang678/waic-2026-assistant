# WAIC UP! AI创作者之夜

> **来源**：网络渠道 · `source_type: unofficial`
> 发布方：ME News WAIC周边活动合集 · 2026-07-19
> 原文：<https://www.me.news/events/648>

## 活动信息（从报道中提取，供参考）

- **地点**：张江科学会堂 五楼光空间

## 摘要

WAIC UP! 系列AI创作者之夜（承办含织码开门）。

---

*非官方来源，信息以官方发布为准 · 本文件由 build.py 自动生成*