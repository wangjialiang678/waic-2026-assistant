# 高鹄资本·AI Frontier talks 论坛

> **来源**：网络渠道 · `source_type: unofficial`
> 发布方：新浪财经
> 原文：<https://finance.sina.com.cn/zt_d/subject-1782718283/>

## 活动信息（从报道中提取，供参考）

- **时间**：2026-07-19 09:30
- **地点**：世博展览馆 H4 领航舞台

---

*非官方来源，信息以官方发布为准 · 本文件由 build.py 自动生成*